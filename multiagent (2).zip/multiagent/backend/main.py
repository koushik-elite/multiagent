import asyncio
import re
import sys
import json
from llama_index.readers.github import GithubRepositoryReader, GithubClient
from dataclasses import dataclass
from crews import CodeMigrationCrew
# import logfire
# logfire.configure()
# logfire.instrument_pydantic()
import time
import pandas as pd
from uuid import uuid4

datetime_reference = pd.read_excel("D:\\prodapt\\agent\\datetime_reference.xlsx")
# Connect to github repository and download code
# look for local folder and file
# scan the code for translation keys/values
# merge the missing value and connvert to v4 format
# migrate Datatime  

# Load the repo from the github
client = github_client = GithubClient(
    github_token="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", verbose=False
)

reader = GithubRepositoryReader(
    github_client=github_client,
    owner="koushik-s-prodapt",
    repo="react-i18next-example",
    use_parser=False,
    verbose=True,
    filter_directories=(
        ["src"],
        GithubRepositoryReader.FilterType.INCLUDE,
    ),
    filter_file_extensions=(
        [
            ".css",".svg",".png",
        ],
        GithubRepositoryReader.FilterType.EXCLUDE,
    ),
)

create_error = False

en_resource_file = "{}"

if __name__ == '__main__':
    en_resource_file = "{}"
    all_documents = reader.load_data(branch="main")
    print("document ------------------------------------------------------------")
    langs = ['es', 'de']
    for document in all_documents:
        file_name = document.extra_info["file_name"]
        if file_name.lower().endswith('.json'):
            if file_name.lower().endswith('en.json'):
                en_resource_file = document.text
    
    print("en_resource_file --------------")
    print(en_resource_file)
    all_modified_codes = []
    for document in all_documents:
        file_name = document.extra_info["file_name"]
        if file_name.lower().endswith(('app.js', 'index.js', 'i18n.js')):
            # print(document.text)
            # print("Pre Code ------------------------")
            input_id = str(uuid4())
            # jscode = JavascriptCode(code=str(document.text), en_json=str(en_resource_file))
            company_research_crew = CodeMigrationCrew(input_id)
            company_research_crew.setup_crew(str(document.text), str(en_resource_file))
            results = company_research_crew.kickoff()
            all_modified_codes.append(results)