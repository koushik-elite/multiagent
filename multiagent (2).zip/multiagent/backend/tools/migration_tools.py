from typing import List, Type
from backend.models import JavascriptCodeResult
from pydantic.v1 import BaseModel, Field
import os
import requests
from crewai_tools import BaseTool
import subprocess

class JavascriptCodeToolInput(BaseModel):
    code: str

class JavascriptPluralCodeTool(BaseTool):
    name: str = "i18next-scanner"
    description: str = "Scan your code, extract translation keys/values, and merge them into i18n resource files."
    args_schema: Type[BaseModel] = JavascriptCodeToolInput

    def _run(self, code: str) -> JavascriptCodeResult:

        subprocess.check_call('npm --help', shell=True)
        gulp_code = """
            const gulp = require('gulp');
            const sort = require('gulp-sort');
            const scanner = require('i18next-scanner');

            gulp.task('i18next', function() {
                return gulp.src(['src/**/*.{js,html}'])
                    .pipe(sort()) // Sort files in stream by path
                    .pipe(scanner({
                        lngs: ['en', 'de'], // supported languages
                        resource: {
                            // the source path is relative to current working directory
                            loadPath: 'assets/i18n/{{lng}}/{{ns}}.json',

                            // the destination path is relative to your `gulp.dest()` path
                            savePath: 'i18n/{{lng}}/{{ns}}.json'
                        }
                    }))
                    .pipe(gulp.dest('assets'));
            });
        """
        result = JavascriptCodeResult(code=subprocess.check_call(f"npm {gulp_code}", shell=True))
        return result