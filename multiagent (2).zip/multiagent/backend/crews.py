from langchain_openai import ChatOpenAI
from log_manager import append_event
from agents import MigrationAgents, react_developer, german_transulator, arabic_transulator
from tasks import MigrationTasks
from crewai import Crew
from uuid import uuid4
import pandas as pd

class CodeMigrationCrew:
    def __init__(self, input_id: str):
        self.input_id = input_id
        self.crew = None
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview")

    def setup_crew(self, code: str, en_json: str):

        # DONE: SETUP AGENTS
        agents = MigrationAgents()

        react_developer_agent = agents.react_developer()
        german_transulator_agent = agents.german_transulator()
        react_developer_with_tool = agents.react_developer_with_tool()

        # DONE: SETUP TASKS
        tasks = MigrationTasks(input_id=self.input_id)

        datetime_reference = pd.read_excel("D:\\prodapt\\agent\\datetime_reference.xlsx")
        datetime_ref_table = datetime_reference.to_markdown()

        all_assigned_tasks = [
            tasks.migrate_plurals(react_developer_agent, code, en_json),
            tasks.migrate_datetime(react_developer_agent, code, en_json, datetime_ref_table),
            tasks.migrate_currency(german_transulator_agent, en_json),
        ]
        
        # DONE: CREATE CREW
        self.crew = Crew(
            agents=[react_developer_agent, german_transulator_agent],
            tasks=all_assigned_tasks,
            verbose=2,
        )

    def kickoff(self):
        if not self.crew:
            print(f"""Crew not found for {self.input_id}""")
            return
        
        append_event(self.input_id, "CREW STARTED")
        
        try:
            print(f"""Running crew for {self.input_id}""")
            results = self.crew.kickoff()
            append_event(self.input_id, "CREW COMPLETED")
            return results

        except Exception as e:
            append_event(self.input_id, "CREW FAILED")
            return str(e)