export default function Header() {
    return (
      <div className="bg-black">
        <div className="mx-auto py-4 px-5">
          <h1 className="text-white text-xl font-bold">
            A Simple CrewAI multi-agent LLM App.
          </h1>
        </div>
      </div>
    );
  }