from typing import List
from pydantic import BaseModel

class JavascriptCode(BaseModel):
    code: str
    en_json: str

class JavascriptCodeResult(BaseModel):
    code: str
    en_json: str
