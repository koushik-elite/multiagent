from crewai import Task, Agent
from textwrap import dedent


from log_manager import append_event
from models import JavascriptCode, JavascriptCodeResult


class MigrationTasks():

    def __init__(self, input_id):
        self.input_id = input_id

    def append_event_callback(self, task_output):
        print(f"Appending event for {self.input_id} with output {task_output}")
        append_event(self.input_id, task_output.exported_output)

    def migrate_datetime(self, agent: Agent, code: str, en_json: str, markdown_table: str, tasks: list[Task]):
        return Task(
            description=dedent(f""" 
                your job is to Scan the given React JS/JS code look for i18next datetime formatting.
                modify or create keys/values in i18next V4 resource JSON using native datetime formatting uses the 'datetime::'.
                remove the interpolation code with respect to datetime/date/time in js code.
                return the modified JS code and i18next V4 resource JSON

                Table given below explains how to migrate from i18next V3 to V4
                {markdown_table}
                ------------------------------------------------------------
                JS Code
                {code}
                -------------------------------------------------------------
                en json
                {en_json}
            """),
            agent=agent,
            expected_output=dedent("""
                A json object containing modified code and EN i18ln json
            """),
            callback=self.append_event_callback,
            context=tasks,
            output_json=JavascriptCodeResult
        )

    def migrate_plurals(self, agent: Agent, code: str, en_json: str, tasks: list[Task]):
        return Task(
            description=dedent(f"""
                your job is to Scan the given React JS/JS code and extract translation keys/values, and merge them into i18n resource JSON.
                do not remove any keys/values just add the missing only.
                migrate final i18next resource JSON to i18next V4 JSON format
                {code}
                -------------------------------------------------------------
                en json
                {en_json}
            """),
            agent=agent,
            expected_output=dedent("""
                A json object containing modified code and EN i18ln json
            """),
            callback=self.append_event_callback,
            context=tasks,
            output_json=JavascriptCodeResult,
        )
    
    def migrate_currency(self, agent: Agent, code: str, en_json: str, tasks: list[Task]):
        return Task(
            description=dedent(f"""
                Scan the given React JS/JS code look for i18next interpolation.
                Important:
                - understand the interpolation code.
                - look for the code which is dealing with currency formatting
                - predict the expected output for that code
                - based on predicted output try to replace code with new i18next V4 native currency formatting
                - Add the required JSON in i18next json

                ------------------------------------------------------------
                JS Code
                {code}
                -------------------------------------------------------------
                en json
                {en_json}
            """),
            agent=agent,
            expected_output=dedent("""
                A json object containing DE i18next json
            """),
            callback=self.append_event_callback,
            context=tasks,
            output_json=JavascriptCodeResult,
        )
    
    def transulate_german(self, agent: Agent, en_json: str, tasks: list[Task]):
        return Task(
            description=dedent(f"""
                your job is to transulate the given i18next V4 JSON and respective values to language code given by user 
                append them into i18n resource JSON and return the appended JSON
                -------------------------------------------------------------
                en.json
                {en_json}
            """),
            agent=agent,
            expected_output=dedent("""
                A json object containing DE i18ln json
            """),
            callback=self.append_event_callback,
            context=tasks,
            output_json=JavascriptCodeResult,
        )
    
    
