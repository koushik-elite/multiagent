import asyncio
import re
import sys
import json
from llama_index.readers.github import GithubRepositoryReader, GithubClient
from dataclasses import dataclass
# import logfire
# logfire.configure()
# logfire.instrument_pydantic()
import time
import pandas as pd

datetime_reference = pd.read_excel("D:\\prodapt\\agent\\datetime_reference.xlsx")
# Connect to github repository and download code
# look for local folder and file
# scan the code for translation keys/values
# merge the missing value and connvert to v4 format
# migrate Datatime  

# Load the repo from the github
client = github_client = GithubClient(
    github_token="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", verbose=False
)

reader = GithubRepositoryReader(
    github_client=github_client,
    owner="koushik-s-prodapt",
    repo="react-i18next-example",
    use_parser=False,
    verbose=True,
    filter_directories=(
        ["src"],
        GithubRepositoryReader.FilterType.INCLUDE,
    ),
    filter_file_extensions=(
        [
            ".css",".svg",".png",
        ],
        GithubRepositoryReader.FilterType.EXCLUDE,
    ),
)

create_error = False

en_resource_file = "{}"

if __name__ == '__main__':
    company_research_crew = TechnologyResearchCrew(input_id)
    company_research_crew.setup_crew(technologies, businessareas)
    results = company_research_crew.kickoff()