from typing import List
from crewai import Agent
from langchain_openai import ChatOpenAI
from crewai_tools import SerperDevTool
from tools.migration_tools import JavascriptPluralCodeTool


class MigrationAgents():

    def __init__(self):
        self.searchInternetTool = SerperDevTool()
        self.scanpluralsTool = JavascriptPluralCodeTool()
        self.llm = ChatOpenAI(model="gpt-4-turbo-preview")
    
    def react_developer_with_tool(self) -> Agent:
        return Agent(
            role="React Javascript Developer",
            goal=f"""
                Scan the given React.js code, and also create or modify any necessary code to perform given task and produce bug free code.
                Important:
                - The final JSON objects must include modified React JS code and ES i18next JSON. Do not leave any out.
                - If there is no code change, just return the same input code and ES i18next JSON.
                - Do not any part of code except i18next JSON and interpolation.
            """,
            backstory="""Your a experienced React Javascript Developer with exceptional coding skill. 
            And also your are good in integrating i18next and Intl with React Javascript framework.
            you are responsible to produce clean and bug free React code.
            """,
            llm=self.llm,
            tools=[self.scanpluralsTool], # TODO: Add tools
            verbose=True,
            allow_delegation=True
        )
    
    def react_developer(self) -> Agent:
        return Agent(
            role="React Javascript Developer",
            goal=f"""
                Scan the given React.js code, and also create or modify any necessary code to perform given task and produce bug free code.
                Important:
                - The final JSON objects must include modified React JS code and ES i18next JSON. Do not leave any out.
                - If there is no code change, just return the same input code and ES i18next JSON.
                - Do not any part of code except i18next JSON and interpolation.
            """,
            backstory="""Your a experienced React Javascript Developer with exceptional coding skill. 
            And also your are good in integrating i18next and Intl with React Javascript framework.
            you are responsible to produce clean and bug free React code.
            """,
            llm=self.llm,
            tools=[], # TODO: Add tools
            verbose=True,
            allow_delegation=True
        )
    
    def german_transulator(self, code: str, en_json: str) -> Agent:
        return Agent(
            role="Language Transulator",
            goal=f"""
                Scan the given i18n JSON key/values and transulate the english sentences in values to german.
            """,
            backstory="""
            Your a Transulator with exceptional proficiency in german And also you are good in creating i18next locale JSON.
            you are responsible to produce clean german transulation for each english sentences.
            """,
            llm=self.llm,
            tools=[], # TODO: Add tools
            verbose=True,
            allow_delegation=True
        )

    def arabic_transulator(self, code: str, en_json: str) -> Agent:
        return Agent(
            role="Language Transulator",
            goal=f"""
                Scan the given i18n JSON key/values and transulate the english sentences in values to arabic.
            """,
            backstory="""Your a Transulator with exceptional proficiency in arabic And also your are good in creating i18next locale JSON
            """,
            llm=self.llm,
            tools=[], # TODO: Add tools
            verbose=True,
            allow_delegation=True
        )
