from pydantic_ai import Agent, RunContext, ModelRetry
from pydantic_ai.models.gemini import GeminiModel
import asyncio
import re
import sys
import json
from pydantic import BaseModel, Field
from llama_index.readers.github import GithubRepositoryReader, GithubClient
from dataclasses import dataclass
# import logfire
# logfire.configure()
# logfire.instrument_pydantic()
import time
import pandas as pd

datetime_reference = pd.read_excel("D:\\prodapt\\agent\\datetime_reference.xlsx")
# Connect to github repository and download code
# look for local folder and file
# scan the code for translation keys/values
# merge the missing value and connvert to v4 format
# migrate Datatime  

# Load the repo from the github
client = github_client = GithubClient(
    github_token="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", verbose=False
)

reader = GithubRepositoryReader(
    github_client=github_client,
    owner="koushik-s-prodapt",
    repo="react-i18next-example",
    use_parser=False,
    verbose=True,
    filter_directories=(
        ["src"],
        GithubRepositoryReader.FilterType.INCLUDE,
    ),
    filter_file_extensions=(
        [
            ".css",".svg",".png",
        ],
        GithubRepositoryReader.FilterType.EXCLUDE,
    ),
)

create_error = False

en_resource_file = "{}"

# Agent 1 Scan the code and identify the missing transulation key/value

@dataclass
class JavascriptCode:
    code: str
    en_json: str

class i18NResource(BaseModel):
    i18n_resource_JSON: str = Field(description='i18n resource JSON')
    code: str = Field(description='Modified JS/javascript code')

model = GeminiModel('gemini-1.5-flash', api_key='AIzaSyAei9YXhd1ptAt5SgKdJHP3V-dN7KBz8Wk')
agent = Agent(
    model,
    deps_type=JavascriptCode,
    result_type=i18NResource
)

@agent.system_prompt  
async def get_system_prompt(ctx: RunContext[JavascriptCode]) -> str:
    responce_format = "{'en':{'translation':{....}}}"
    code = ctx.deps.code
    en_json = ctx.deps.en_json
    system_prompt = f"""
you are helpful assistant and your job is to Scan the given React JS/JS code and extract translation keys/values, and merge them into i18n resource JSON.
do not remove any keys/values just add the missing only.
migrate final i18next resource JSON to i18next V4 JSON format
{code}
-------------------------------------------------------------
en json
{en_json}

Expected Responce Format:
{responce_format}
"""
    return system_prompt


# Agent 2 Migrate all v3 datetime to v4 datetime 

datetime_agent = Agent(
    model,
    deps_type=JavascriptCode,
    result_type=i18NResource
)

@datetime_agent.system_prompt  
async def get_system_prompt(ctx: RunContext[JavascriptCode]) -> str:
    markdown_table = datetime_reference.to_markdown()
    # print(markdown_table)
    responce_format = "{'en':{'translation':{....}}}"
    code = ctx.deps.code
    en_json = ctx.deps.en_json
    system_prompt = f"""
you are helpful assistant and your job is to Scan the given React JS/JS code look for i18next datetime formatting.
modify or create keys/values in i18next V4 resource JSON using native datetime formatting uses the 'datetime::'.
remove the interpolation code with respect to datetime/date/time in js code.
return the modified JS code and i18next V4 resource JSON

Table given below explains how to migrate from i18next V3 to V4
{markdown_table}
------------------------------------------------------------
JS Code
{code}
-------------------------------------------------------------
en json
{en_json}
"""
    return system_prompt


# Agent 3 Migrate all v3 currency to v4 currency 

currency_agent = Agent(
    model,
    deps_type=JavascriptCode,
    result_type=i18NResource
)

@currency_agent.system_prompt  
async def get_system_prompt(ctx: RunContext[JavascriptCode]) -> str:
    markdown_table = datetime_reference.to_markdown()
    # print(markdown_table)
    responce_format = "{'en':{'translation':{....}}}"
    code = ctx.deps.code
    en_json = ctx.deps.en_json
    system_prompt = f"""
you are helpful assistant and your job is to Scan the given React JS/JS code look for i18next datetime formatting.
modify or create keys/values in i18next V4 resource JSON using native datetime formatting uses the 'datetime::'.
remove the interpolation code with respect to datetime/date/time in js code.
return the modified JS code and i18next V4 resource JSON

Table given below explains how to migrate from i18next V3 to V4
{markdown_table}
------------------------------------------------------------
JS Code
{code}
-------------------------------------------------------------
en json
{en_json}
"""
    return system_prompt




@dataclass
class Eni18NResource:
    json: str

migrate_agent = Agent(
    model,
    deps_type=Eni18NResource,
    result_type=i18NResource
)

@agent.result_validator  
async def validate_result(ctx: RunContext[JavascriptCode], final_response: i18NResource) -> i18NResource:
    global create_error
    i18n_resource_JSON = final_response.i18n_resource_JSON

    if create_error:
        i18n_resource_JSON = i18n_resource_JSON + "{}"
        create_error = False

    try:
        # print(i18n_resource_JSON)
        json.loads(i18n_resource_JSON)
    except json.decoder.JSONDecodeError:
        raise ModelRetry(f'JSON format is incorrect, retrying... {final_response.i18n_resource_JSON}')
    
    # try:
    #     # Run pyton subprocess npm test typescript
    #     pass
    # except json.decoder.JSONDecodeError:
    #     raise ModelRetry(f'JSON format is incorrect, retrying... {final_response.i18n_resource_JSON}')

    return final_response

@migrate_agent.system_prompt  
async def get_system_prompt(ctx: RunContext[Eni18NResource]) -> str:
    en_json = ctx.deps.json
    system_prompt = f"""
you are helpful assistant, and your job is to transulate the given i18next V4 JSON and respective values to language code given by user 
append them into i18n resource JSON and return the appended JSON
-------------------------------------------------------------
en.json
{en_json}
"""
    return system_prompt

def loadfiles():
    global en_resource_file
    all_documents = reader.load_data(branch="main")
    print("document ------------------------------------------------------------")
    # print(all_documents)
    langs = ['es', 'de']
    for document in all_documents:
        file_name = document.extra_info["file_name"]
        if file_name.lower().endswith('.json'):
            # print(document.text)
            if file_name.lower().endswith('en.json'):
                en_resource_file = document.text
    
    print("en_resource_file --------------")
    print(en_resource_file)

    all_results = []
    # call the agent to fix the code
    for document in all_documents:
        file_name = document.extra_info["file_name"]
        if file_name.lower().endswith(('app.js', 'index.js', 'i18n.js')):
            # print(document.text)
            # print("Pre Code ------------------------")
            deps = JavascriptCode(code=str(document.text), en_json=str(en_resource_file))
            # result = agent.run_sync('extract translation keys/values in i18next V4 JSON format', deps=deps)
            
            result = datetime_agent.run_sync('migrate datetime to i18next V4 JSON format', deps=deps)
            en_resource_file = result.data.i18n_resource_JSON
            all_results.append(result.data)
            time.sleep(3)
  

    # time.sleep(4)
    # for lang in langs:
    #     deps = Eni18NResource(json=str(en_resource_file))
    #     result = migrate_agent.run_sync(f"transulate to {lang}", deps=deps)
    #     en_resource_file = result.data.i18n_resource_JSON
    #     time.sleep(3)

    
    print("Final ------------------------------------------------------------")
    for code in all_results:
        print(code.code)
        print("Code ------------------------")

    print(en_resource_file)

    # Create saperate file and save data
    # raise PR request

if __name__ == '__main__':
    # print(RULES)
    loadfiles()
    # result = agent.run_sync('Where does "hello world" come from?')  
    # print(result.data)